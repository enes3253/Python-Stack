from flask import Flask, render_template

app = Flask (__name__)

@app.route('/play')
def play():
    return render_template("app.html" , times = 3)

@app.route('/play/<int:num>')
def play(num):
    return render_template("app.html" , times=num)

@app.route('/play/<int:num>/<color>')
def play(num, color):
    return render_template("app.html" , times=num , color=color)

if __name__=='__main__':
    app.run(debug=True)